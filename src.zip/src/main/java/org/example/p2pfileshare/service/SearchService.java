package org.example.p2pfileshare.service;

import java.util.Collections;
import java.util.List;

public class SearchService {

    // TODO: sau này có thể lưu metadata, index, v.v.
    public List<Object> search(String keyword, String subject, String peerName) {
        // Tạm thời trả list rỗng
        return Collections.emptyList();
    }
}
